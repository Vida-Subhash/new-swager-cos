# swagger-docs
How create Swagger documents for API. 

# Install Dependence
`npm install`

# Run 
`npm run dev`